-- Copyright 2004-2023 H2 Group. Multiple-Licensed under the MPL 2.0,
-- and the EPL 1.0 (https://h2database.com/html/license.html).
-- Initial Developer: H2 Group
--

select cot(null) vn, cot(-1) r1;
> VN   R1
> ---- -------------------
> null -0.6420926159343306
> rows: 1
