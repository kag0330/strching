-- Copyright 2004-2023 H2 Group. Multiple-Licensed under the MPL 2.0,
-- and the EPL 1.0 (https://h2database.com/html/license.html).
-- Initial Developer: H2 Group
--

select cos(null) vn, cos(-1) r1;
> VN   R1
> ---- ------------------
> null 0.5403023058681398
> rows: 1
